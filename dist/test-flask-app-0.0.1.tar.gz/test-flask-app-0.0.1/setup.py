import setuptools

setuptools.setup(
    name="test-flask-app",
    version="0.0.1",
    description="test flask app",
    author="Chaitanya Varma",
    packages=setuptools.find_packages(),
    license='MIT'
)
